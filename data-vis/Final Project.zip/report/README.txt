I have included pdfs of all my answers in each of the folders for each question.

In addition I have included my app diagram in the q2 folder relating to question 2. 

Also in the q3 folder I have included a jpeg of my finished Gantt chart outlining the planning of my time over the course of this project. 

In the q4 folder I have included my testing documentations.

Finally in this folder, I have included my progress reports over the second half of this semester